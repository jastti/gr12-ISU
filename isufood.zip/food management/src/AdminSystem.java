package Tsystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollBarUI;

import com.sun.net.httpserver.Authenticator.Result;



public class AdminSystem implements ADO<Admin>{

	static Map<String, Admin> map = new HashMap<>();
	static String orderIndex = "0000";//order initialize.
	static String userIndex = "0000";//order initialize.
	static String dishIndex = "000";//order initialize.
	
//  static Set<String> keys = map.keySet();
	UserSystem u = new UserSystem();
	OrderSystem o = new OrderSystem();
	DishSystem d = new DishSystem();
	Scanner sc = new Scanner(System.in);
	User us = new User();
	
    public void addDish() throws IOException {
        System.out.println("Enter Dish:(Dish ID/Dish name/Dish type/price)");
        String str = sc.next();
        String[] info = str.split("/");
//        String[] u_info ;//存放用户信息；
        //
//        try{
////          
//             String mytxt = info[0] + ", " + info[1] + ", " + info[2] + ", "  + info[3] ;
//             FileWriter fw = new FileWriter("dish.txt",true);
//             PrintWriter pw=new PrintWriter(fw);
//             pw.println(mytxt+"\n");//字符串末尾不需要换行符
//             pw.close () ;
//             fw.close () ;
//             
//             String mytxt2 = u_info[0] + ", " + u_info[1] + ", " + u_info[2] + ", "  + u_info[3] ;
//             FileWriter u_fw = new FileWriter("dish.txt",true);
//             PrintWriter u_pw=new PrintWriter(u_fw);
//             pw.println(mytxt2+"\n");//字符串末尾不需要换行符
//             u_pw.close () ;
//             u_fw.close () ;
//             
//             
//          }
//         catch(FileNotFoundException e){
//          e.printStackTrace();
//          }
        
        if (info.length < 4) {
            System.out.println("Wrong enter! Re-enter: ");
            addDish();
        } else {
//            LocalDate dtime = LocalDate.now();
            Dish t = new Dish(info[0], info[1], info[2], Double.parseDouble(info[3]));
            d.add(t);
            System.out.println("Dish added");
        }
    }
    
    public Dish addDishToWin(String dId, String dName, String dType, Double dPrice)  {
    	dishIndex = codeAddOne(dishIndex, 3);// 订单长度为4，前面不足补0；
		if (d.find(dishIndex) == null) {// 对dish进行唯一性验证，重复的订单号，不允许新增；
			  Dish t = new Dish(dishIndex, dName, dType, dPrice);
	            d.add(t);
	            System.out.println("Dish added: ");
	            return t;
		} else {
			System.out.println("The dish is repeated!!");
			return null;
			
		}
    }
    
    public void deleteDish() {
    	System.out.println("Enter the dish ID of the dish you want to delete: ");
    	String id = sc.next();
        d.delete(id);
        System.out.println("Deleted");
    }
    
    public Boolean deleteDishToWin(String id) {
        System.out.println("Deleted");
        if (d.find(id) == null) {// 如果没有查到该订单，直接返回删除识别
			return false;
		} else {
			d.delete(id);// 找到说明没有删除，否则成功
	        System.out.println("Deleted");
			return true;
		}
        
    }
    
//    public void viewAllDish(int pageSize) {
//    	List<Dish> dl = d.findAll();
//    	int start = 0;
//    	 while (true) {
//             if (dl.size() > (pageSize + start)) {
//                 System.out.println(dl.subList(start, pageSize + start));
//
//             } else {
//                 System.out.println(dl.subList(start, dl.size()));
//                 break;
//             }
//             start = start + pageSize;
//         }
//    }
    public void viewAllDish() {
    	List<Dish> dl = d.findAll();
//    	int start = 0;
    	 while (true) {
//                 System.out.println(dl.subList(start, dl.size()));
    		 System.out.println(dl);
                 break;
             }
         
    }
    
    public Dish[] viewAllDishToWin() {
    	List<Dish> dl = d.findAll();
    	Collections.sort((List<Dish>) dl);//显示的订单进行排序
//    	int start = 0;
    	
    	int i = dl.size();
    	//将List转化为数组，加载到JCombox中
    	Dish[] dishInfo = (Dish[]) dl.toArray(new Dish[i]);//返回Dish类到Combox，可以直接解决下述问题；还有一个可选方案是用JTable，有时间再研究；
//    	String[] dishInfo = new String[i];//如返回只是菜单的名字，在窗口就会出现id、name、type、price的同步问题
//    	String[][] dishInfo = new String[i][4];//如返回是二维数组，会有2个问题：price类型转换；toString的打印问题
   //给二维数组赋值，对应Dish的Id，type，name，price 	
//    	for (Dish dish : dl) {
//    		dishInfo[i-1][0] = dish.getDishID();
//    		dishInfo[i-1][1] = dish.getDishType(); //创建和dishlist相同多元素的String数组
//    		dishInfo[i-1][2] = dish.getDishName(); //创建和userList相同多元素的String数组
//    		dishInfo[i-1][3] = String.valueOf(dish.getPrice());
//    		i --;
//		}
    	System.out.println(dishInfo.toString());//为避免出现打印：[LTsystem.Dish;@621f8e2b这样的信息，需定义toString方法，类似重载；
			return dishInfo;
	}
    
    public void priceChange() {
        System.out.println("Enter the dish ID：");
        String id = sc.next();
        Dish dish = d.find(id);
        if (dish == null) {
            System.out.println("Not found");
        } else {
            System.out.println("Dish：" + dish);
            System.out.println("Enter new price：");
            double newprice = sc.nextDouble();
            Dish t = new Dish(dish.getDishID(), dish.getDishName(), dish.getDishType(), newprice);
            d.add(t);
            System.out.println("successful!" + d.find(t.getDishID()));
        }
    }
    
    public Dish priceChange(String id, double dPrice) {
        Dish dish = d.find(id);
        if (dish == null) {
            System.out.println("Not found");
            return null;
        } else {
            System.out.println("Dish：" + dish);
            double newprice = dPrice;
            Dish t = new Dish(dish.getDishID(), dish.getDishName(), dish.getDishType(), newprice);
            d.add(t);
            System.out.println("successful!" + d.find(t.getDishID()));
            return t;
        }
    }

    public void addUser() {
    	 System.out.println("Enter user info:(User ID/User Name/User Address/User phone number)");
         String str = sc.next();
         String[] info = str.split("/");
         if (info.length < 4) {
             System.out.println("Wrong enter! Re-enter: ");
             addUser();
         } else {
             User user = new User(info[0], info[1], info[2], info[3]);
             u.add(user);
             System.out.println("User added");
         }
    }
    
    public User addUserToWin(String uid, String name, String address, String phone) {
            
            userIndex = codeAddOne(userIndex, 4);
            User user = new User(userIndex, name, address, phone);
            u.add(user);
            System.out.println("User added");
        return user;
   }
    
    public void deleteUser() {
    	System.out.println("Enter the user ID of the user you want to delete: ");
    	String id = sc.next();
        u.delete(id);
        while(u.equals(null)) {
        System.out.println("Deleted");
        }
    }
    
	public Boolean deleteUserToWin(String id) {
		if (u.find(id) == null) {// 如果没有查到该订单，直接返回删除识别
			return false;
		} else {
			u.delete(id);// 找到说明没有删除，否则成功
			return true;
		}

	}
    
    public void viewUser() {
    	List<User> userList = u.findAll();
    	for(User user:userList) {
    		System.out.println(user);
    	}
    }
    
    
    
    public User[] viewUserToWin() {
		List<User> userList = u.findAll();
		Collections.sort((List<User>) userList);//显示的订单进行排序
		int i = userList.size();
		User[] userInfo = (User[]) userList.toArray(new User[i]);
//		String[][] userInfo = new String[i][4];
//		for (User user : userList) {
//			userInfo[i - 1][0] = user.getUserID();
//			userInfo[i - 1][1] = user.getUserName(); // 创建和userList相同多元素的String数组
//			userInfo[i - 1][2] = user.getUserAddress();
//			userInfo[i - 1][3] = user.getUserPhone();
//			System.out.println(userInfo[i - 1][1]);
//			i--;
//		}
//		System.out.println(userInfo);
		return userInfo;
	}
    
    public User findUser(String ID) {
    	System.out.println(u.find(ID));
    	return u.find(ID);
    }
    
    public User findUserToWin(String ID) {
    	System.out.println(u.find(ID));
    	return u.find(ID);
    }
    
    public void showOrderList(User user) {
    	List<Order> order = o.findByUser(user.getUserID());
    	for(Order or:order) {
    		System.out.println(or);
    	}
    }
    
    public List<Order> showOrderListToWin(User user) {
    	List<Order> orderList = o.findByUser(user.getUserID());
    	Collections.sort((List<Order>) orderList);//显示的订单进行排序
    	for(Order or: orderList ) {
    		System.out.println(or);
    	}
    	return orderList;
    }
    
    public void showOrderList() {
        List<Order> allOrder = o.findAll();
        Collections.sort((List<Order>) allOrder);//显示的订单进行排序
        for (Order order : allOrder) {
            System.out.println(order);
        }
    }
    
    public List<Order> showOrderListToWin() {
        List<Order> allOrder = o.findAll();
        Collections.sort((List<Order>) allOrder);//显示的订单进行排序
        for (Order order : allOrder) {
            System.out.println(order);
        }
        return allOrder;
    }
    
    public void buyDish(User user) {
//    	List<Dish> list = d.findAll();
    	System.out.println("Enter the dish you want to buy(DishID/ Quantity): ");
    	String str = sc.next();
        String[] info = str.split("/");
        if(info.length < 2) {
        	System.out.println("Wrong enter! Re-enter: ");
        	buyDish(user);
        } else {
        	LocalDateTime time = LocalDateTime.now();
//        	DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");  
//            String formatDateTime = time.format(format); 
        	String userId = user.getUserID();
        	System.out.println(info[0]);// dish id
        	System.out.println(time);
        	System.out.println(d.find(info[0]));
        	int quantity = Integer.parseInt(info[1]);// order num
        	System.out.println(quantity);
        	System.out.println(userId);
        	System.out.println(d.find(info[0]).getPrice());
        	double oPrice = quantity*(d.find(info[0]).getPrice());// orderprice
        	System.out.println(oPrice);
        	orderIndex = codeAddOne(orderIndex,4);//订单长度为4，前面不足补0；
        	if (o.find(orderIndex)==null) {//对订单进行唯一性验证，重复的订单号，不允许新增；
        		Order order = new Order(orderIndex, time, d.find(info[0]), quantity,
                		userId, oPrice);
                o.add(order);
                System.out.println("Order: " + o.find(orderIndex).toString());
			}
        	else {
				System.out.println("The order is repeated!!");
			}
            
        } 
    }
    
	public Order buyDishToWin(User user, String dishID, Integer quantity) {
		List<Dish> list = d.findAll();
		LocalDateTime time = LocalDateTime.now();
		String userId = user.getUserID();
		System.out.println(dishID);// dish id
		System.out.println(time);
		System.out.println(d.find(dishID));
		System.out.println(quantity);
		System.out.println(userId);
		System.out.println(d.find(dishID).getPrice());
		double oPrice = quantity * (d.find(dishID).getPrice());// orderprice
		System.out.println(oPrice);
		orderIndex = codeAddOne(orderIndex, 4);// 订单长度为4，前面不足补0；
		if (o.find(orderIndex) == null) {// 对订单进行唯一性验证，重复的订单号，不允许新增；
			Order order = new Order(orderIndex, time, d.find(dishID), quantity, userId, oPrice);
			o.add(order);
			System.out.println("Order: " + o.find(orderIndex).toString());
			return order;
		} else {
			System.out.println("The order is repeated!!");
			return null;
			
		}
		

	}

    public void DishByType() {
        System.out.println("Enter dish type: ");
        String str = sc.next();
        System.out.println(d.findByType(str));
    }
    
    
    public Dish[] DishByTypeToWin(String dishType) {
		// TODO Auto-generated method stub
    	 List<Dish> dishList = d.findByType(dishType);
    	 int i = dishList.size();
     	//将List转化为数组，加载到JCombox中
     	Dish[] dishInfo = (Dish[]) dishList.toArray(new Dish[i]);
//         System.out.println(dishList);
         System.out.println(dishInfo.toString());//为避免出现打印：[LTsystem.Dish;@621f8e2b这样的信息，需定义toString方法，类似重载；
		return dishInfo;
	}
    
    public static String codeAddOne(String code, int len){
    	   Integer intHao = Integer.parseInt(code);
    	   intHao++;
    	   String strHao = intHao.toString();
    	   while (strHao.length() < len) {
    	       strHao = "0" + strHao;
    	     }
    	   return strHao;
    	}
    
    public void readFile() throws FileNotFoundException {
    	try {//加载dish文件
			File file = new File("src/dish2.txt");
			Scanner scan = new Scanner(file);
			String code1 = null;
			
			if(file.exists()) {
				int dCount = 1 ;
				while (scan.hasNext()) {
					code1 = scan.nextLine();// read the string in this line.
					final String[] words = code1.split("[, ]+");
					System.out.println(words + " is ok");
					String sd = words[0];
					if (dCount == 1) {
						dishIndex = sd; //文件中订单按照逆序存放，并提取第一条数据，作为订单号的初始值，新增订单按照数学递增。
						dCount ++;
					}
//					Dishes d1 = new Dishes("1", "红烧猪蹄", "肉类", time, 12.5, 20, 30);
					Dish d1 = new Dish(words[0], words[1], words[2],  Double.parseDouble(words[3]));
					d.add(d1);
				}
			}
		
			
		} catch (Exception e) {
			System.out.println("文件读取失败");
	
        }
    	
    	try {//加载user
			File file = new File("src/user2.txt");
			Scanner scan = new Scanner(file);
			String code1 = null;
			if(file.exists()) {
				int uCount = 1;
				while (scan.hasNext()) {
					code1 = scan.nextLine();// read the string in this line.
					final String[] words = code1.split("[, ]+");
					System.out.println(words + " is ok");
					String su = words[0];
					if (uCount == 1) {
						userIndex = su; //文件中订单按照逆序存放，并提取第一条数据，作为订单号的初始值，新增订单按照数学递增。
						uCount ++;
					}
					User u1 = new User(words[0], words[1], words[2],  words[3]);
					u.add(u1);
				}
			}
		
			
		} catch (Exception e) {
			System.out.println("文件读取失败");
	
        }
    	
    	try {//加载order
			File file = new File("src/order2.txt");
			Scanner scan = new Scanner(file);
			String code1 = null;
			int count=1;
			if(file.exists()) {
				while (scan.hasNext()) {
					code1 = scan.nextLine();// read the string in this line.
					final String[] words = code1.split("[,][ ]+"); //按照规则截取字符串并存入数组
					System.out.println(words + " is ok");
//					DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM-dd-yyyy hh:mm:ss");
					Dish d1 = new Dish(words[2], words[3], words[4], Double.parseDouble(words[5]));
//					Dishes d1 = new Dishes("1", "红烧猪蹄", "肉类", time, 12.5, 20, 30);
//					addDishUsingRegex(code1);// 测试正则的函数
//					Order o1 = new Order(words[0], LocalDateTime.parse(words[1],fmt), d1, Integer.parseInt(words[6]), words[7], Double.parseDouble(words[8]));
					String s0 = words[0];
//					LocalDateTime s1 = LocalDateTime.parse(words[1]);
					DateTimeFormatter df = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");//规范化日期格式，在程序加载和文件中保持一致；
					LocalDateTime s1 = LocalDateTime.parse(words[1],df);//把文件的日期格式转化成类中日期的格式
					System.out.println("String类型的时间转成LocalDateTime："+s1);//打印并监控
					
					Integer s6 = Integer.parseInt(words[6]);
					String s7 = words[7];
					Double s8 = Double.parseDouble(words[8]);
					if (count == 1) {
						orderIndex = s0; //文件中订单按照逆序存放，并提取第一条数据，作为订单号的初始值，新增订单按照数学递增。
					    count ++;
					}
				
					Order o1 = new Order(s0, s1, d1, s6, s7, s8);
					
//					Order o1 = new Order(words[0], LocalDateTime.parse(words[1]), d1, Integer.parseInt(words[6]), words[7], Double.parseDouble(words[8]));
					o.add(o1);
//					String orderID, LocalDateTime orderTime, Dish dish, int orderNum, String userID, Double orderPrice)
				}
			}
		
			
		} catch (Exception e) {
			System.out.println("文件读取失败");
	
        }
	}
    

    
    public void exitSystem()  {
//		ObjectOutputStream oos;
		try {
//			oos = new ObjectOutputStream(
//					new FileOutputStream("src/dishes.txt"));
//			File d_file = new File("src/dish1.txt");
//			File u_file = new File("src/user1.txt");
//			File o_file = new File("src/order1.txt");
			FileWriter d_fw = new FileWriter("src/dish2.txt",false);
            PrintWriter d_pw = new PrintWriter(d_fw);
            List<Dish> dishList = d.findAll();
            Collections.sort((List<Dish>) dishList);//按照逆序存放记录
            for (Dish dish : dishList) {
            	System.out.println(dish);
            	String d_String = dish.getDishID()  +", " + dish.getDishName()  +", " + dish.getDishType()  +", " + dish.getPrice();
        		d_pw.println(d_String);//字符串末尾不需要换行符
			}	
            d_pw.close () ;
            d_fw.close () ;
            
            FileWriter u_fw = new FileWriter("src/user2.txt",false);
            PrintWriter u_pw = new PrintWriter(u_fw);
            List<User> userList = u.findAll();
            Collections.sort((List<User>) userList);//按照逆序存放记录
        	for(User user:userList) {
        		System.out.println(user);
        		String u_String = user.getUserID() +", " + user.getUserName() +", " + user.getUserAddress() +", " + user.getUserPhone();
        		u_pw.println(u_String);//字符串末尾不需要换行符
        	}
       	 u_pw.close () ;
         u_fw.close () ;
         
         
        	 FileWriter o_fw = new FileWriter("src/order2.txt",false);
             PrintWriter o_pw = new PrintWriter(o_fw);
        	List<Order> orderList = o.findAll();
        	Collections.sort((List<Order>) orderList);
        	for(Order order: orderList) {
        		System.out.println(order);
        		DateTimeFormatter df = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
        		LocalDateTime time = order.getOrderTime();
				String localTime = df.format(time);
				String d_price = String.valueOf(order.getDish().getPrice());
				Double o_priceDouble = order.getOrderPrice();
				String o_price = String.valueOf(o_priceDouble);
        		String o_String = order.getOrderID() +", " + localTime +", " 
        		+ order.getDish().getDishID() +", " + order.getDish().getDishName() +", " 
        				+ order.getDish().getDishType() +", " 
        		+ d_price +", " + order.getOrderNum() + ", " + order.getUserID() +", " 
        				+ o_price;
        		o_pw.println(o_String);//字符串末尾不需要换行符
        	}
            o_pw.close () ;
            o_fw.close () ;
//			oos.writeObject(d);
//			oos.flush();
//			oos.close();
		} catch (Exception e) {
			System.out.println("文件关闭失败");
		}
	}
    
    public void deleteOrder() {
    	System.out.println("Enter the order ID of the order you want to delete: ");
    	String id = sc.next();
//    	Boolean delBoolean = false;
    	o.delete(id); //把u改成o，原程序无删除订单功能
//        while(o.equals(null)) {//这个逻辑不对
//        System.out.println("Deleted");
//        }
        o.findAll();
    }
    
    public Boolean deleteOrderToWin(String orderID) {
    	System.out.println(orderID);
//    	Boolean delBoolean = false;
    		if (o.find(orderID)==null) {//如果没有查到该订单，直接返回删除识别
    			return false;
    		}
            else {
            	o.delete(orderID);// 找到说明没有删除，否则成功
    			return true;
    		}
    }
    
	public void delete(String ID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Admin find(String ID) {
		// TODO Auto-generated method stub
		return map.get(ID);
	}

	@Override
	public List findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(Admin t) {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		AdminSystem ad = new AdminSystem();
		
		for(int i = 0; i>=0; i++) {
		System.out.println("ENTER:");
		Scanner sc = new Scanner(System.in);
		int st = sc.nextInt();
		
		if (st == 1) {
//			Scanner sc1 = new Scanner(System.in);
		try {
			ad.addDish();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} else if (st == 2) {
		ad.viewAllDish();
		} else if (st == 3) {
			ad.deleteDish();
			}
		else if (st == 4) {
			ad.addUser();
		}
		else if (st == 5) {
			ad.deleteUser();
		}
		else if (st == 6) {
			ad.viewUser();
		} else if (st == 7) {
			Scanner sc2 = new Scanner(System.in);
			String s = sc2.toString();
			ad.findUser(s);
		} else if (st == 8) {
//			ad.showOrderList();
		} else if (st == 9) {
//			ad.buyDish();
		} else if (st == 10){
			System.exit(0);
		}
		}
	}
	/* 12345/burger/food/5.6
	 * 35221/noodle/food/7.6
	 * 34210/rice/food/3
	 * 74219/pasta/food/12.6
	 */

	public void addMessage() throws FileNotFoundException {
		// TODO Auto-generated method stub
//		map.put("admin", new Admin("10086", "admin", "123456"));
		map.put("admin", new Admin("10086", "123456", "admin"));
		readFile();
//        LocalDate time = LocalDate.now();
//        Dish d1 = new Dish("1", "红烧猪蹄", "肉类", 12.5);
//        d.add(d1);
//        Dish d2 = new Dish("2", "鸡公煲", "肉类", 21.5);
//        d.add(d2);
//        Dish d3 = new Dish("3", "麻辣香锅", "火锅类", 30);
//        d.add(d3);
//        Dish d4 = new Dish("4", "水煮肉片", "肉类", 15);
//        d.add(d4);
//        Dish d5 = new Dish("5", "水果沙拉", "水果类", 6);
//        d.add(d5);
        // String orderID, LocalDateTime utime, Dishes dishes, int ordernum, String uID,
        // Double orderprice,int orderValue
//        LocalDateTime localdatetime = LocalDateTime.now();
//        Order o1 = new Order("1", localdatetime, d1, 10, "1001", 60.0);
//        o.add(o1);
//        Order o2 = new Order("2", localdatetime, d2, 5, "1002", 50.0);
//        o.add(o2);
//        Order o3 = new Order("3", localdatetime, d3, 5, "1003", 40.0);
//        o.add(o3);
//        Order o4 = new Order("4", localdatetime, d4, 5, "1004", 30.0);
//        o.add(o4);
//        Order o5 = new Order("5", localdatetime, d5, 5, "1005", 20.0);
//        o.add(o5);
        // String uID, String uname, String usex, String upwd, String uadress, String
        // utel, LocalDateTime utime
//        User u1 = new User("1001", "张三", "男", "123456");
//        u.add(u1);
//        User u2 = new User("1002", "李四", "男", "234567");
//        u.add(u2);
//        User u3 = new User("1003", "王五", "男", "345678");
//        u.add(u3);
//        User u4 = new User("1004", "刘柳", "女", "456789");
//        u.add(u4);
//        User u5 = new User("1005", "赵琦", "女", "567890");
//        u.add(u5);
	}

	
}
