package Tsystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;

public class TAdmin extends JFrame  implements ActionListener{

//	private JPanel contentPane;
	private JTextField dishID;
	private JTextField dishName;
	private JTextField dishPrice;
	private JTextField userID;
	private JTextField userPhone;
	private JTextField userName;
	private JTextField userAddress;
	private JPanel contentPane_x;//新增用于返回主窗口
//	private static JPanel contentPane_x_copy;//新增用于？
	tt frame;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					TAdmin frame = new TAdmin();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public TAdmin(tt frame) {
//		public TAdmin() {
		this.frame = frame;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 773, 498);
		contentPane_x = new JPanel();//初始化
//		contentPane = new JPanel();//暂时不用了
//		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_x.setBorder(new EmptyBorder(5, 5, 5, 5));
		add(contentPane_x);//新增
//		setContentPane(contentPane);//暂时不用
//		contentPane.setLayout(null);
		contentPane_x.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Dish ID");
		lblNewLabel.setBounds(36, 20, 58, 15);
//		contentPane.add(lblNewLabel);//暂时不用
		contentPane_x.add(lblNewLabel);
		
		dishID = new JTextField();
		dishID.setBounds(23, 45, 97, 21);
		contentPane_x.add(dishID);//替换_x
		dishID.setColumns(10);
		
		dishName = new JTextField();
		dishName.setBounds(135, 45, 115, 21);
		contentPane_x.add(dishName);//替换_x
		dishName.setColumns(10);
		
		JComboBox dishType = new JComboBox();
		dishType.setBounds(23, 119, 123, 23);
		contentPane_x.add(dishType);//替换_x
		
		dishPrice = new JTextField();
		dishPrice.setBounds(184, 120, 66, 21);
		contentPane_x.add(dishPrice);//替换_x
		dishPrice.setColumns(10);
		
		JButton btnAddDish = new JButton("Add");
		btnAddDish.setBounds(287, 20, 97, 23);
		contentPane_x.add(btnAddDish);//替换_x
		
		JButton btnSearchDish = new JButton("Search");
		btnSearchDish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		btnSearchDish.setBounds(287, 86, 97, 23);
		contentPane_x.add(btnSearchDish);//替换_x
		
		JButton btnDeleteDish = new JButton("Delete");
		btnDeleteDish.setBounds(287, 53, 97, 23);
		contentPane_x.add(btnDeleteDish);//替换_x
		
		JButton btnChangePrice = new JButton("Change Price");
		btnChangePrice.setBounds(287, 119, 97, 23);
		contentPane_x.add(btnChangePrice);//替换_x
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(144, 20, 58, 15);
		contentPane_x.add(lblNewLabel_1);//替换_x
		
		JLabel lblNewLabel_2 = new JLabel("Price");
		lblNewLabel_2.setBounds(178, 95, 58, 15);
		contentPane_x.add(lblNewLabel_2);//替换_x
		
		JLabel lblNewLabel_3 = new JLabel("Type");
		lblNewLabel_3.setBounds(36, 94, 58, 15);
		contentPane_x.add(lblNewLabel_3);//替换_x
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(410, 20, 293, 122);
		contentPane_x.add(textPane);//替换_x
		
		userID = new JTextField();
		userID.setColumns(10);
		userID.setBounds(23, 201, 97, 21);
		contentPane_x.add(userID);//替换_x
		
		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setBounds(36, 176, 58, 15);
		contentPane_x.add(lblUserId);//替换_x
		
		JLabel lblNewLabel_3_1 = new JLabel("Address");
		lblNewLabel_3_1.setBounds(36, 250, 58, 15);
		contentPane_x.add(lblNewLabel_3_1);//替换_x
		
		userPhone = new JTextField();
		userPhone.setColumns(10);
		userPhone.setBounds(135, 276, 115, 21);
		contentPane_x.add(userPhone);//替换_x
		
		JLabel lblNewLabel_2_1 = new JLabel("Phone");
		lblNewLabel_2_1.setBounds(135, 250, 58, 15);
		contentPane_x.add(lblNewLabel_2_1);//替换_x
		
		userName = new JTextField();
		userName.setColumns(10);
		userName.setBounds(135, 201, 115, 21);
		contentPane_x.add(userName);//替换_x
		
		JLabel lblNewLabel_1_1 = new JLabel("Name");
		lblNewLabel_1_1.setBounds(144, 176, 58, 15);
		contentPane_x.add(lblNewLabel_1_1);//替换_x
		
		JButton btnAddUser = new JButton("Add");
		btnAddUser.setBounds(287, 176, 97, 23);
		contentPane_x.add(btnAddUser);//替换_x
		
		JButton btnDeleteUser = new JButton("Delete");
		btnDeleteUser.setBounds(287, 209, 97, 23);
		contentPane_x.add(btnDeleteUser);//替换_x
		
		JButton btnSearchUser = new JButton("Search");
		btnSearchUser.setBounds(287, 246, 97, 23);
		contentPane_x.add(btnSearchUser);//替换_x
		
		JButton btnChangeUser = new JButton("Change Price");
		btnChangeUser.setBounds(287, 275, 97, 23);
		contentPane_x.add(btnChangeUser);//替换_x
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBounds(410, 176, 293, 122);
		contentPane_x.add(textPane_1);//替换_x
		
		JTextPane textPane_2 = new JTextPane();
		textPane_2.setBounds(23, 391, 680, 70);
		contentPane_x.add(textPane_2);//替换_x
		
		JButton orderList = new JButton("Show All Orders");
		orderList.setBounds(48, 344, 145, 23);
		contentPane_x.add(orderList);//替换_x
		
		JButton userLogin = new JButton("User Login");
//		userLogin.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				
//			}
//		});
		userLogin.addActionListener(this);
		userLogin.setBounds(287, 344, 97, 23);
		contentPane_x.add(userLogin);
		
		userAddress = new JTextField();
		userAddress.setColumns(10);
		userAddress.setBounds(23, 275, 97, 21);
		contentPane_x.add(userAddress);
	}
	
	public JPanel view() {
        return contentPane_x;
    }
	
	public void actionPerformed (ActionEvent event) {
		String eventName = event.getActionCommand();
		if (eventName.equals ("User Login")) {
			frame.setVisible(true);
			setVisible(false);
			System.out.println("login in user window");
		}
	}

}
