package Tsystem;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class tt extends JFrame implements WindowListener {

//	private JPanel contentPane;
	JPanel contentPane;// 改成全局的
	private JTextField orderNum;
	JPanel panel;// 主函数提供显示，不用看！
	static TAdmin1 m1;
	static TLogin m2;
	static tt frame;
	static AdminSystem admin = new AdminSystem();
//	Scanner sc = new Scanner(System.in);
//	static Menu menu = new Menu();
//	static User u = new User();
	JComboBox<Dish[]> dishName;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					tt frame = new tt();
					frame = new tt();
					m1 = new TAdmin1(frame);
					m2 = new TLogin(frame, m1);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws FileNotFoundException
	 */
	public tt() throws FileNotFoundException {
		admin.addMessage();//启动后台，加载信息

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 603, 389);
		contentPane = new JPanel();// 新建一个Jpanel
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
//		contentPane.add(textArea);
		// JScrollPane作为容器，承载TextArea的内容，并实现滚动条
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 171, 569, 169);
//		scrollPane.add(textArea);
		contentPane.add(scrollPane); // 将scrollPane装入到contentPane容器中

		JTextArea textArea = new JTextArea();
		textArea.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);// 自左到右的展示
		textArea.setRows(100);
		textArea.setBounds(10, 171, 569, 169);

		scrollPane.setViewportView(textArea);// can add the scrollPane to the textarea.

		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setBounds(20, 28, 71, 15);
		contentPane.add(lblNewLabel);
		JComboBox<User[]> userCombo = new JComboBox(admin.viewUserToWin());
		userCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText(null);// 清空显示窗，用户只能看自己的订单；
			}
		});
		userCombo.setBounds(91, 24, 359, 23);
		
		contentPane.add(userCombo);

		dishName = new JComboBox(admin.viewAllDishToWin());
		dishName.setBounds(20, 105, 359, 23);
		contentPane.add(dishName);
		
		
		

		orderNum = new JTextField();
		orderNum.setBounds(389, 106, 61, 21);
		// 校验输入有效的数字
		orderNum.setDocument(new NumberDocument());// 调用JTextFile的setDocument将NumberDocument设置
		contentPane.add(orderNum);
		orderNum.setColumns(10);

		JLabel dishPrice = new JLabel("Dish Info");
		dishPrice.setBounds(23, 87, 58, 15);
		contentPane.add(dishPrice);

		JButton adminLog = new JButton(" To Admin Login");
		adminLog.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
//				contentPane.remove(panel);
				frame.setVisible(false);
//                TAdmin s = new TAdmin();
//                panel = s.view();
//				TLogin s = new TLogin();
//				panel = s.view();
//                panel.setBounds(0, 49, 693, 487);
//                contentPane.add(panel);
//                panel.setLayout(null);
//                update(getGraphics());
				// 亮点在这，panel一定要是全局的！
				System.out.println("show admin login");
//        		TLogin m = new TLogin();
//                panel = m.view();
//                panel.setBounds(100, 100, 450, 196);
//                contentPane.add(panel);
//                panel.setLayout(null);
				m2.setVisible(true);
			}
		});
		adminLog.setForeground(Color.MAGENTA);
		adminLog.setBounds(453, 24, 127, 23);
		contentPane.add(adminLog);

		JLabel lblNewLabel_2 = new JLabel("Amount");
		lblNewLabel_2.setBounds(392, 87, 58, 15);
		contentPane.add(lblNewLabel_2);

		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				admin.exitSystem();
				System.exit(0);

			}
		});
		btnQuit.setBounds(453, 79, 127, 23);
		contentPane.add(btnQuit);



		JButton addOrder = new JButton("Add");
		addOrder.setBounds(55, 138, 97, 23);
//		addOrder.addActionListener(this);
		addOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				User userID = (User)userCombo.setSelectedItem().value;
//				userCombo.getSelectedItem();
//				userCombo.getSelectedObjects();
				dishName.setModel(new DefaultComboBoxModel(admin.viewAllDishToWin()));//用这个方法可以实现刷新Combox内容，只是需要手工操作。
				userCombo.setModel(new DefaultComboBoxModel(admin.viewUserToWin()));//用这个方法可以实现刷新Combox内容，只是需要手工操作。
				User selectedUser = (User) userCombo.getSelectedItem();// 选择Combox的user信息，作为参数传递；
				Dish selectedDish = (Dish) dishName.getSelectedItem();// 选择Combox的dishID信息，作为参数传递

				String input = "";// 初始化输入字符串，避免无输入时直接增加订单
				input = orderNum.getText();
				if (!input.equals("")) {
					Integer value = Integer.parseInt(input);// 获取JTextField内容,将字符串转换成Integer类型的数
					System.out.println(value);
					Order addedOrder = admin.buyDishToWin(selectedUser, selectedDish.getDishID(), value);
					textArea.setText(null);// 清空显示窗
					textArea.append("\nThe User ID: " + addedOrder.getUserID() + "\t the order ID:"
							+ addedOrder.getOrderID() + "\t Order Time: " + addedOrder.getOrderTime() + "\n");
					textArea.append("Dish ID \t Dish Name \t  Dish Price \t" + "Quality \t  Subtotal   \n");
					textArea.append(addedOrder.getDish().getDishID() + "\t" + addedOrder.getDish().getDishName() + "\t"
							+ addedOrder.getDish().getPrice() + "\t" + addedOrder.getOrderNum() + "\t"
							+ addedOrder.getOrderPrice() + "\n");
					textArea.append("\n*****************\n");
					System.out.println(addedOrder.toString());

				} else {
					JOptionPane.showMessageDialog(contentPane, "Please input the valid amount! ", "warning",
							JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		contentPane.add(addOrder);

		JButton cancelOrder = new JButton("Delete");
		cancelOrder.setBounds(182, 138, 97, 23);
		cancelOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String orderID;
				orderID = JOptionPane.showInputDialog(contentPane, "Please enter the order you want to deleted");
				
				textArea.setText(null);// 清空显示窗
				
				if(admin.deleteOrderToWin(orderID)) {
				textArea.append("\t The order: " + orderID + " was deleted! " + "\n");
				}
				else {
					textArea.append("\t No order: " + " was deleted! " + "\n");
				}
			}
		});
		contentPane.add(cancelOrder);

		JButton orderList = new JButton("My History Orders");
		orderList.setBounds(310, 138, 140, 23);
		orderList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				List<Order> orders;
//				Order orderItem;
				User selectedUser = (User) userCombo.getSelectedItem();// 选择Combox的user信息，作为参数传递；
				orders = admin.showOrderListToWin(selectedUser);// 根据选定的用户，查找所有的订单，返回值为List<Order>;
				textArea.setText(null);// 清空显示窗

				if (orders.isEmpty()) {// 如果返回值为空，打印告警
					textArea.append("\nThe User ID: " + selectedUser.getUserID() + " has not order right now!\n");
				}

				for (Iterator<Order> iterator = orders.iterator(); iterator.hasNext();) {
					Order orderItem1 = (Order) iterator.next();
					textArea.append("\nThe User ID: " + orderItem1.getUserID() + "\t the order ID:"
							+ orderItem1.getOrderID() + "\t Order Time: " + orderItem1.getOrderTime() + "\n");
					textArea.append("Dish ID \t Dish Name \t  Dish Price \t" + "Quality \t  Subtotal   \n");
					textArea.append(orderItem1.getDish().getDishID() + "\t" + orderItem1.getDish().getDishName() + "\t"
							+ orderItem1.getDish().getPrice() + "\t" + orderItem1.getOrderNum() + "\t"
							+ orderItem1.getOrderPrice() + "\n");
					textArea.append("\n*****************\n");
				}
			}
		});
		contentPane.add(orderList);

		/*
		 * //创建DishType，并初始化 JComboBox<String> dishType = new JComboBox<String>();
		 * dishType.setBounds(91, 57, 169, 23); //给dishType赋值，为dishName的第一个元素 Dish
		 * selectedDish0 = (Dish) dishName.getSelectedItem();
		 * dishType.addItem(selectedDish0.getDishType()); dishType.addActionListener(new
		 * ActionListener() { public void actionPerformed(ActionEvent e) { Dish[]
		 * dishes; String selectedDish = (String) dishType.getSelectedItem();//
		 * 选择Combox的type信息，作为参数传递； dishes = (Dish[]) admin.DishByTypeToWin(selectedDish)
		 * ;// 根据选定的用户，查找所有的订单，返回值为List<Order>; textArea.setText(null);// 清空显示窗 if
		 * (dishes.length!=0) { dishName.removeAllItems();
		 * dishName.addItem(dishes.toString()); // for (int i = 0; i < dishes.length;
		 * i++) { // dishName.addItem(dishes[i]); // }
		 * 
		 * }
		 * 
		 * 
		 * 
		 * } }); contentPane.add(dishType);
		 */
		
		

		/*
		 * JLabel lblType = new JLabel("Dish Type"); lblType.setBounds(23, 61, 58, 15);
		 * contentPane.add(lblType);
		 */

		JLabel lblPleaseSelectUser = new JLabel("Please Select the User Name");
		lblPleaseSelectUser.setBounds(122, 10, 173, 15);
		contentPane.add(lblPleaseSelectUser);

//		admin.addMessage();
//		dishName.addItem(admin.viewAllDishToCombox()); 
	}

//	Dish[] dishes = new Dish[];
//								 dishes = admin.viewUserToWin(); frame.contentPane.dishName.setModel(new
//								 DefaultComboBoxModel(dish));
	@Override
	public void windowActivated(WindowEvent e) {
		System.out.println("windowActivated--->窗口被选中"); //尝试在tt中写windowevent，但是无法触发，遗留问题。
		dishName.setModel(new DefaultComboBoxModel(admin.viewAllDishToWin()));//用这个方法可以实现刷新Combox内容，只是需要手工操作。
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

								 
}
