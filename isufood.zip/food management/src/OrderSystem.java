package Tsystem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class OrderSystem implements ADO<Order>{
	
	static Map<String, Order> orderSys = new HashMap<>();
	static List<Order> ol = new ArrayList<>();

	@Override
	public void add(Order t) {
		// TODO Auto-generated method stub
//		if (find(t.getOrderID()==null)) 
		{
			orderSys.put(t.getOrderID(), t);
		}
		
	}

	@Override
	public void delete(String ID) {
		// TODO Auto-generated method stub
		if (orderSys.get(ID) == null) {
            System.out.println("Wrong ID, re-enter: ");
//            return false;//不能设为bool，因为接口定义的是void，周边的改动较大。
        } else {
        	orderSys.remove(ID);
        	System.out.println("Deleted");
//        	return true;
        }
	}

	@Override
	 public Order find(String ID) {
        if (orderSys.get(ID) == null) {
            return null;
        } else {
            return orderSys.get(ID);
        }

    }
	
	public List<Order> findByUser(String userID) {
		// TODO Auto-generated method stub
		 List<Order> list = new ArrayList<>();
	        Set<String> keys = orderSys.keySet();
	        for (String key : keys) {
	            if (Objects.equals(userID, orderSys.get(key).getUserID())) {
	                list.add(orderSys.get(key));
	                
	            }
//	            else {//不能有这个条件判断部分。因为是遍历所有的订单，只有是该用户的订单才会遍历到，不是该用户的不会增加进来。如果有else部分，遇到非该用户的订单，就会终止遍历。
//					System.out.println("No orders was found for this user!");
//					break;
//				}
	        }
			return list;
	        
	}

	@Override
	public List<Order> findAll() {
		  // TODO Auto-generated method stub
		  List<Order> orderlist = new ArrayList<>();
		   Set<String> keys = orderSys.keySet();
		         for (String key : keys) {
		          orderlist.add(orderSys.get(key));
		         }
		         return orderlist;
		 }

}
