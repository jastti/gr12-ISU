package Tsystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.Scanner;

public class Menu {
	static AdminSystem admin = new AdminSystem();
    Scanner sc = new Scanner(System.in);
    static Menu menu = new Menu();
    static User u = new User();
   

    public void showMenu() throws FileNotFoundException {
        admin.addMessage();
//        while()
        System.out.println("1: Admin; 2: User\nEnter your choice:");
      Scanner s = new Scanner(System.in);
    String str = s.nextLine();
    if(str.equals("1")) {
        adminMenu();
    } else if(str.equals("2")) {
    	System.out.println("User ID:");
    	String UserLogin = sc.next();
    	User user = admin.findUser(UserLogin);
        userMenu(user);
    }
//        System.out.println("Enter account and password(account/password): ");
//        String str = sc.next();
//        String[] info = str.split("/");
//        if (info.length < 2) {
//            System.out.println("Wrong input! Re-enter: ");
//            showMenu();
//        } else {
//            if (admin.find(info[0]) != null && Objects.equals(admin.find(info[0]).getAdminPswd(), info[1])) {
//                adminMenu();
//            } else if (admin.findUser(info[0]) != null
//                    && Objects.equals(info[1], admin.findUser(info[0]).getUserID())) {
//                User user = admin.findUser(info[0]);
//                userMenu(user);
//            } else {
//                System.out.println("Wrong input! Re-enter: ");
//                showMenu();
//            }
//        }

    }
    
	private void userMenu(User user) {
		// TODO Auto-generated method stub
		System.out.println("====【1】Buy Dish=================");
        System.out.println("====【2】Display dish by category===");
        System.out.println("====【3】Display all dishes============");
        System.out.println("====【4】Change to Admin Menu===============");
        System.out.println("====【5】Order list============");
        System.out.println("====【6】Exit==================");
        System.out.println("请输入您要进行的操作：");
        String n = sc.next();
        switch (n) {
        case "1":
            admin.buyDish(user);
            userMenu(user);
            break;
        case "2":
            admin.DishByType();
            userMenu(user);
            break;
        case "3":
            admin.viewAllDish();
            userMenu(user);
            break;
        case "4":
        	System.out.println("Admin Menu: ");
        	menu.adminMenu();
            break;
        case "5":
            admin.showOrderList(user);
            userMenu(user);
            break;
        case "6":
        	admin.exitSystem();
            System.out.println("Bye!");
            System.exit(0);
        default:
            System.out.println("Wrong input! Re-enter: ");
            userMenu(user);
        }
	}

	private void adminMenu() {
		// TODO Auto-generated method stub
        System.out.println("====【1】Add dish===============");
        System.out.println("====【2】Display all dishes=======");
        System.out.println("====【3】Display dish by category=====");
        System.out.println("====【4】Change dish price=====");
        System.out.println("====【5】Delete dish=========");
        System.out.println("====【6】Add user================");
        System.out.println("====【7】Display user list=============");
        System.out.println("====【8】Delete user==========");
        System.out.println("====【9】Display order list=============");
        System.out.println("====【10】Change to User Menu====");
        System.out.println("====【11】Exit=================");
        String m = sc.next();
        switch (m) {
        case "1":
            try {
				admin.addDish();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            adminMenu();
            break;
        case "2":
//            System.out.println("请输入您需要每行显示多少数据：");
//            int pageSize = sc.nextInt();
            admin.viewAllDish();
            adminMenu();
            break;
        case "3":
            admin.DishByType();
            adminMenu();
            break;
        case "4":
            admin.priceChange();
            adminMenu();
            break;
        case "5":
            admin.deleteDish();
            adminMenu();
            break;
        case "6":
            admin.addUser();
            adminMenu();
            break;
        case "7":
            admin.viewUser();
            adminMenu();
            break;
        case "8":
            admin.deleteUser();
            adminMenu();
            break;
        case "9":
            admin.showOrderList();
            adminMenu();
            break;
        case "10":
        	System.out.println("User ID:");
            String UserLogin = sc.next();
            User user = admin.findUser(UserLogin);
        	System.out.println("User Menu: ");
        	menu.userMenu(user);
            break;
        case "11":
        	admin.exitSystem();
        	System.out.println("Bye!");
            System.exit(0);
            break;
        default:
            System.out.println("Wrong input! Re-enter: ");
            adminMenu();
        }
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try {
		      File myObj = new File("filename.txt");
		      if (myObj.createNewFile()) {
//		        System.out.println("File created: " + myObj.getName());
		      } else {
//		        System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
//		User u = new User();
//		System.out.println("1: Admin; 2: User");
//        Scanner s = new Scanner(System.in);
//      String str = s.nextLine();
//      if(str == "1") {
//    	  menu.adminMenu();
//      } else if(str == "2") {
//    	  User user = admin.findUser(str);
//    	  menu.userMenu(user);
//      } else {
//        System.out.println("Wrong input! Re-enter: ");
//        menu.showMenu();
//    }
		menu.showMenu();
//		menu.adminMenu();
//		menu.userMenu(u);
	}

}
