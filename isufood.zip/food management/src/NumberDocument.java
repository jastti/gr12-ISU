package Tsystem;

import java.awt.Toolkit;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class NumberDocument extends PlainDocument {
    public NumberDocument() {
    }

    public void insertString(int var1, String var2, AttributeSet var3) throws BadLocationException {
        if (this.isNumeric(var2)) {
            super.insertString(var1, var2, var3);
        } else {
            Toolkit.getDefaultToolkit().beep();
        }

    }

    private boolean isNumeric(String var1) {
        try {
            Long.valueOf(var1);
            return true;
        } catch (NumberFormatException var3) {
            return false;
        }
    }
}

//以下方法也可以实现校验数字输入
/*
 * class NumberTextField extends PlainDocument { public NumberTextField() {
 * super(); }
 * 
 * public void insertString(int offset, String str, AttributeSet attr) throws
 * javax.swing.text.BadLocationException { if (str == null) { return; }
 * 
 * char[] s = str.toCharArray(); int length = 0; // 过滤非数字 for (int i = 0; i <
 * s.length; i++) { if ((s[i] >= '0') && (s[i] <= '9')) { s[length++] = s[i]; }
 * // 插入内容 super.insertString(offset, new String(s, 0, length), attr); } } }
 */ 