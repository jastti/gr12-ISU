package Tsystem;

//import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.sun.org.apache.xml.internal.dtm.ref.dom2dtm.DOM2DTM;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TLogin extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField account;
	private JPasswordField passwordField;
	tt frame;
//	TLogin m2;
	TAdmin m1;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					TLogin frame = new TLogin();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public TLogin(tt frame, TAdmin m1) {
		this.frame = frame;
		this.m1 = m1;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 196);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
//		setContentPane(contentPane);//暂时去掉，增加下一行
		add(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(29, 55, 58, 15);
		contentPane.add(lblNewLabel_1);
		
		account = new JTextField();
		account.setColumns(10);
		account.setBounds(104, 55, 115, 21);
		contentPane.add(account);
		
		
		JButton btnLogin = new JButton("Login");
//		btnLogin.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				m2.setVisible(false);
//			}
//		});
		btnLogin.addActionListener (this);
		btnLogin.setBounds(284, 51, 97, 23);
		contentPane.add(btnLogin);
		
		JButton btnCancel = new JButton("Cancel");
//		btnCancel.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//			}
//		});
		btnCancel.addActionListener (this);
		btnCancel.setBounds(284, 93, 97, 23);
		contentPane.add(btnCancel);
		
		JLabel lblNewLabel_1_1 = new JLabel("Name");
		lblNewLabel_1_1.setBounds(29, 94, 58, 15);
		contentPane.add(lblNewLabel_1_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(104, 94, 117, 21);
		contentPane.add(passwordField);
	}
	

	public JPanel view() {
		// TODO Auto-generated method stub
		return contentPane;
	}
	
	public void actionPerformed (ActionEvent event) {
		String eventName = event.getActionCommand();
		if (eventName.equals ("Login")) {
			frame.setVisible(true);
			m1.setVisible(true);
			setVisible(false);
			System.out.println("show the login window");
		}
	}
}
